package com.example.apidemoopenweather.models

data class Wind(
    val deg: Int,
    val gust: Double,
    val speed: Double
)