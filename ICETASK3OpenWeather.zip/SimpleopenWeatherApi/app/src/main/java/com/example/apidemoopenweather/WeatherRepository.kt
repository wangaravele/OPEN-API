package com.example.apidemoopenweather.repository

import android.net.Uri
import android.util.Log
import com.example.apidemoopenweather.models.weatherModel
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.MalformedURLException
import java.net.URL

class WeatherRepository {

    companion object {
        private const val BASE_URL = "https://api.openweathermap.org/data/2.5/forecast"
        private const val PARAM_LAT = "lat"
        private const val LAT = -25.7459277
        private const val PARAM_LON = "lon"
        private const val LON = 28.1879101
        private const val PARAM_API_KEY = "appid"
        private const val API_KEY = "PUT YOUR API_KEY HERE"
    }

    suspend fun getWeatherData(): weatherModel? {
        return withContext(Dispatchers.IO) {
            try {
                val data = buildURLForWeather()?.readText()

                data?.let {
                    Gson().fromJson(it, weatherModel::class.java)
                }
            } catch (e: Exception) {
                e.printStackTrace()
                null
            }
        }
    }

    private fun buildURLForWeather(): URL? {
        val buildUri: Uri = Uri.parse(BASE_URL).buildUpon()
            .appendQueryParameter(PARAM_API_KEY, API_KEY)
            .appendQueryParameter(PARAM_LAT, LAT.toString())
            .appendQueryParameter(PARAM_LON, LON.toString())
            .appendQueryParameter("units", "metric")
            .build()

        return try {
            URL(buildUri.toString())
        } catch (e: MalformedURLException) {
            e.printStackTrace()
            null
        }.also {
            Log.i("OpenApi", "buildURLForWeather: $it")
        }
    }
}
