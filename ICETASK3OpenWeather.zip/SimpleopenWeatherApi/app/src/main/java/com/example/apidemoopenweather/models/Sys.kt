package com.example.apidemoopenweather.models

data class Sys(
    val pod: String
)