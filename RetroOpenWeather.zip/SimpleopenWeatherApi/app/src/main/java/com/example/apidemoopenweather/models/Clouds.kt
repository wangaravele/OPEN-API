package com.example.apidemoopenweather.models

data class Clouds(
    val all: Int
)