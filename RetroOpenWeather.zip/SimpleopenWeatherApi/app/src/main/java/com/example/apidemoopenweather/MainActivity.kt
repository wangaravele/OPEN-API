package com.example.apidemoopenweather

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.fragment.app.FragmentManager
import com.example.apidemoopenweather.models.Forecast3hour
import com.example.apidemoopenweather.repository.WeatherRepository
import com.example.apidemoopenweather.viewmodel.WeatherViewModel
import com.example.apidemoopenweather.viewmodel.WeatherViewModelFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.MalformedURLException
import java.net.URL

class MainActivity : AppCompatActivity() {

    private lateinit var viewModel: WeatherViewModel
    private lateinit var frag: itemFragment
    private lateinit var fragManager: FragmentManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize the ViewModel
        val repository = WeatherRepository()
        val viewModelFactory = WeatherViewModelFactory(repository)
        viewModel = ViewModelProvider(this, viewModelFactory).get(WeatherViewModel::class.java)

        // Initialize Fragment Manager
        frag = itemFragment()
        fragManager = supportFragmentManager
        fragManager.beginTransaction().replace(R.id.frameLayout, frag, "current").commit()
        fragManager.executePendingTransactions()

        // Observe LiveData from the ViewModel
        viewModel.weatherData.observe(this, Observer { weatherModel ->
            weatherModel?.let {
                val dataList = it.list

                val day5: ArrayList<Forecast3hour> = arrayListOf()
                for (i in dataList.indices step 8) {
                    day5.add(dataList[i])
                }

                frag.setAdapter(day5.toList())
            } ?: run {
                Toast.makeText(this, "Failed to retrieve data", Toast.LENGTH_SHORT).show()
            }
        })

        viewModel.errorMessage.observe(this, Observer { error ->
            error?.let {
                Toast.makeText(this, it, Toast.LENGTH_LONG).show()
            }
        })

        // Fetch weather data
        viewModel.fetchWeatherData()
    }
}
