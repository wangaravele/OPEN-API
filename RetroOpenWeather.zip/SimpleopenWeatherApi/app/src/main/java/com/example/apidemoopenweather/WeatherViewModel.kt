package com.example.apidemoopenweather.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.apidemoopenweather.models.weatherModel
import com.example.apidemoopenweather.repository.WeatherRepository
import kotlinx.coroutines.launch

class WeatherViewModel(private val repository: WeatherRepository) : ViewModel() {

    private val _weatherData = MutableLiveData<weatherModel>()
    val weatherData: LiveData<weatherModel> get() = _weatherData

    private val _errorMessage = MutableLiveData<String>()
    val errorMessage: LiveData<String> get() = _errorMessage

    fun fetchWeatherData() {
        viewModelScope.launch {
            try {
                val result = repository.getWeatherData()
                if (result != null) {
                    _weatherData.postValue(result)
                } else {
                    _errorMessage.postValue("Error: Unable to fetch weather data.")
                }
            } catch (e: Exception) {
                _errorMessage.postValue("Exception: ${e.message}")
            }
        }
    }
}
