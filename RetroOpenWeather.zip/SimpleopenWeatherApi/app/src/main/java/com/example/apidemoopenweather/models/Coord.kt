package com.example.apidemoopenweather.models

data class Coord(
    val lat: Double,
    val lon: Double
)